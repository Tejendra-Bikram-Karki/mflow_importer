jQuery(document).ready(function($) {
  // Import Products button click event
  $('#mflow-import-button').on('click', function() {
      $.ajax({
          url: mflow_importer_ajax['ajax_url'],
          method: 'POST',
          data: {
              action: 'mflow_importer_import_products',
          },
          beforeSend: function() {
              // Show loading message or spinner
              $('#mflow-import-status').html('Importing products...');
          },
          success: function(response) {
              if (response.success) {
                  // Products imported successfully
                  $('#mflow-import-status').html('Products imported successfully.');
              } else {
                  // Failed to import products
                  $('#mflow-import-status').html('Failed to import products.');
              }
          },
          error: function() {
              // AJAX request failed
              $('#mflow-import-status').html('Error: Failed to import products.');
          }
      });
  });
});
