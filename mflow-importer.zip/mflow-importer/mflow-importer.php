<?php
/**
 * Plugin Name: MFlow Importer
 * Description: Import products from MFlow ERP API to WooCommerce
 * Version: 1.0.0
 * Author: Tejendra Bikram Karki
 */

// Define API credentials
define('MFLOW_API_BASE_URL', 'https://stage.mflow.co.il/api/v1');
define('MFLOW_API_PUBLIC_KEY', 'pk_dd9da640f0e6174fd3819fc642557ed7');
define('MFLOW_API_SECRET_KEY', 'sk_04ddbf3e6702ace9a24064ed0bd42f1b');

// Register the MFlow Importer plugin
function mflow_importer_register() {
    add_menu_page('MFlow Importer', 'MFlow Importer', 'manage_options', 'mflow-importer', 'mflow_importer_admin_page');
}
add_action('admin_menu', 'mflow_importer_register');

// Render the MFlow Importer admin page
function mflow_importer_admin_page() {
    ?>
    <div class="wrap">
        <h1>MFlow Importer</h1>
        <p>Click the button below to import products from MFlow ERP API to WooCommerce.</p>
        <button class="button button-primary" id="mflow-import-button">Import Products</button>
        <div id="mflow-import-status"></div>
    </div>
    <?php
}


// Enqueue the required scripts
function mflow_importer_enqueue_scripts() {
    // Enqueue the mflow-importer-script
    wp_enqueue_script('mflow-importer-script', plugin_dir_url(__FILE__) . 'mflow-importer.js', array('jquery'), '1.0.0', true);

    // Localize the script with the AJAX URL
    wp_localize_script('mflow-importer-script', 'mflow_importer_ajax', array('ajax_url' => admin_url('admin-ajax.php')));
}
add_action('admin_enqueue_scripts', 'mflow_importer_enqueue_scripts');


// AJAX handler for importing products
function mflow_importer_ajax_import_products() {
    $response = array('success' => false, 'message' => 'Failed to import products.');

    // Retrieve products from MFlow ERP API
    $products = mflow_importer_fetch_products();

    if ($products) {
        foreach ($products as $product_data) {
            mflow_importer_create_product($product_data);
        }

        $response['success'] = true;
        $response['message'] = 'Products imported successfully.';
    }

    wp_send_json($response);
}
add_action('wp_ajax_mflow_importer_import_products', 'mflow_importer_ajax_import_products');

// Fetch products from MFlow ERP API
function mflow_importer_fetch_products() {
    $api_url = MFLOW_API_BASE_URL . '/products/listAll';
    $headers = array(
        'x-mflow-public-key' => MFLOW_API_PUBLIC_KEY,
        'x-mflow-secret-key' => MFLOW_API_SECRET_KEY
    );

    $response = wp_remote_get($api_url, array('headers' => $headers));

    if (is_wp_error($response)) {
        return false;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (isset($data['success']) && $data['success'] === 1 && isset($data['products'])) {
        return $data['products'];
    }
    

    return false;
}

// Create WooCommerce product
function mflow_importer_create_product($product_data) {
    $product_type = $product_data['type']; // 'Single' or 'Variable'
        // Set the product type
        if ($product_type === 'Single') {
            $product = new WC_Product_Simple();
        } elseif ($product_type === 'Variable') {
            $product = new WC_Product_Variable();
        } else {
            // Unsupported product type
            return;
        }
    
        // Set the product data
        $product->set_name($product_data['name']);
        $product->set_description($product_data['description']);
        $product->set_sku($product_data['sku']);
        $product->set_regular_price($product_data['price']);
        $product->set_manage_stock($product_data['manage_stock']);
        $product->set_stock_quantity($product_data['stock_quantity']);
    
        // Set product images
        if (isset($product_data['images']) && is_array($product_data['images'])) {
            foreach ($product_data['images'] as $image) {
                $attachment_id = mflow_importer_upload_image($image['src']);
                if ($attachment_id) {
                    $product->add_image($attachment_id);
                }
            }
        }
    
        // Save the product
        $product->save();
    
        // Handle variable product variations
        if ($product_type === 'Variable' && isset($product_data['variations']) && is_array($product_data['variations'])) {
            foreach ($product_data['variations'] as $variation_data) {
                mflow_importer_create_variation($product, $variation_data);
            }
        }
    }


    
    // Upload product image
    function mflow_importer_upload_image($image_url) {
        $upload_dir = wp_upload_dir();
        $image_data = file_get_contents($image_url);
        $filename = basename($image_url);
        $upload_file = $upload_dir['path'] . '/' . $filename;
        file_put_contents($upload_file, $image_data);
    
        $wp_filetype = wp_check_filetype($filename, null);
        $attachment = array(
            'post_mime_type' => $wp_filetype['type'],
            'post_title' => sanitize_file_name($filename),
            'post_content' => '',
            'post_status' => 'inherit'
        );
    
        $attachment_id = wp_insert_attachment($attachment, $upload_file);
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        $attachment_data = wp_generate_attachment_metadata($attachment_id, $upload_file);
        wp_update_attachment_metadata($attachment_id, $attachment_data);
    
        return $attachment_id;
    }


    
    // Create variation for variable product
function mflow_importer_create_variation($product, $variation_data) {
    $variation = new WC_Product_Variation();
    $variation->set_parent_id($product->get_id());
    $variation->set_sku($variation_data['sku']);
    $variation->set_regular_price($variation_data['price']);
    $variation->set_manage_stock($variation_data['manage_stock']);
    $variation->set_stock_quantity($variation_data['stock_quantity']);
    
    // Set variation attributes
    $attributes = array();
    foreach ($variation_data['attributes'] as $attribute_key => $attribute_value) {
        $attribute = new WC_Product_Attribute();
        $attribute->set_id(0);
        $attribute->set_name($attribute_key);
        $attribute->set_options(array($attribute_value));
        $attribute->set_position(0);
        $attribute->set_visible(true);
        $attribute->set_variation(true);
        $attributes[] = $attribute;
    }
    
    $variation->set_attributes($attributes);
    $variation->save();
}


    

   
